mex ./geodesics/comp_geodesics_to_all.cpp 
mex ./geodesics/comp_geodesics_pairs.cpp 